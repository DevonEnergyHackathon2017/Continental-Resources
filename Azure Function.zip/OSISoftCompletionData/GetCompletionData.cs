using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Azure.EventHubs;
using System.Threading;

namespace OSISoftCompletionData
{

    public class TimeAttributes
    {
        public int ID { get; set; }
        public double? Stage { get; set; }
        public string WellName { get; set; }
        public DateTime TimeStamp { get; set; }
        public double? TreatingPressure { get; set; }
        public double? SlurryRate { get; set; }
        public double? SlurryTotal { get; set; }
        public double? BlenderPropData { get; set; }
        public double? BlenderPropTotal { get; set; }
    }


    public static class GetCompletionData
    {
        static string sqlConnectionString = "Server=tcp:dvnhckthon-clr.database.windows.net,1433;Initial Catalog=completions;Persist Security Info=False;User ID=hacker;Password=Password1;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        static string EhConnectionString = "Endpoint=sb://pistream.servicebus.windows.net/;SharedAccessKeyName=default;SharedAccessKey=q9LDw+r0g0FxIs/2+hi2lmrF98aLTqpj/SgUGqGYYpo=";
        static string EhEntityPath = "pistreameventhub";


        /// <summary>
        /// This will run and push messages on EventHub
        /// </summary>
        /// <param name="myTimer"></param>
        /// <param name="log"></param>
        [FunctionName("GetCompletionData")]
        public static void Run([TimerTrigger("1 * * * * *")]TimerInfo myTimer, TraceWriter log)

        {
            log.Info($"C# Timer trigger function executed at: {DateTime.Now}");

            //get data from the server
            using (SqlConnection cnn = new SqlConnection(sqlConnectionString))
            {
                cnn.Open();
                var sql = "select lastshown from LoopConfig";
                int next = 0;
                using (SqlCommand cmd = new SqlCommand(sql, cnn))
                {
                    var reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            next = reader.GetInt32(0);
                        }
                    }
                    reader.Close();
                }


                var nextnext = next + 1;
                //sql = "select ID, Stage, wellName, TimeStamp, TreatingPressure, SlurryRate, SlurryTotal, BlenderPropData, BlenderPropTotal from TimeAttributes where id = " + next;
                sql = "select ID, Stage, wellName, TimeStamp, TreatingPressure, SlurryRate, SlurryTotal, BlenderPropData, BlenderPropTotal from TimeAttributes order by id";

                var hasRows = false;
                //while (hasRows == false)
                //{
                using (SqlCommand cmd = new SqlCommand(sql, cnn))
                {
                    var reader = cmd.ExecuteReader();

                    hasRows = reader.HasRows;

                    if (hasRows)
                    {

                        var dt = new DataTable();
                        dt.Load(reader);


                        foreach (DataRow drow in dt.Rows)
                        {
                            try
                            {
                                var t = new TimeAttributes();
                                t.ID = (int)drow["ID"];
                                t.Stage = drow["Stage"] as double?;
                                t.WellName = (string)drow["wellName"];
                                t.TimeStamp = (DateTime)drow["TimeStamp"];
                                t.TreatingPressure = drow["TreatingPressure"] as double?;
                                t.SlurryRate = drow["SlurryRate"] as double?;
                                t.SlurryTotal = drow["SlurryTotal"] as double?;
                                t.BlenderPropData = drow["BlenderPropData"] as double?;
                                t.BlenderPropTotal = drow["BlenderPropTotal"] as double?;

                                var str = JsonConvert.SerializeObject(t);
                                //Console.Write("Message sent");
                                SendMessageToEventHub(str);
                                Thread.Sleep(500);
                            }
                            catch (Exception ex)
                            {
                                log.Error(ex.Message + "\n"+ ex.StackTrace);
                                ;//eat up boys
                            }
                        }
                    }

                    //else
                    //{
                    //    next = 1;
                    //}

                    reader.Close();
                }
                //}

                sql = "update loopconfig set lastshown = " + nextnext;
                using (SqlCommand cmd = new SqlCommand(sql, cnn))
                {
                    var reader = cmd.ExecuteNonQuery();
                }

                log.Info("Processed ID:"+next);

                cnn.Close();
            }

            
        }

        private static void SendMessageToEventHub(string message)
        {
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(EhConnectionString)
            {
                EntityPath = EhEntityPath
            };

            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            var t = eventHubClient.SendAsync(new EventData(Encoding.UTF8.GetBytes(message)));
            t.Wait();
        }


    }

}
